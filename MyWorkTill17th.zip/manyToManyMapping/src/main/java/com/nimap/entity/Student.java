package com.nimap.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="student")
public class Student {
	private String firstName;
	private String lastName;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	//for unidirectional,only first entity is related to the second. The second entity is not related to the first.

	
	@ManyToMany( cascade = CascadeType.PERSIST)
	@JoinTable(name="courseMembership",joinColumns = {
            @JoinColumn(name = "student_id", referencedColumnName = "id"
                    )},
    inverseJoinColumns = {
            @JoinColumn(name = "course_id", referencedColumnName = "id"
                  )})
	private Set<Course> courses = new HashSet<>();
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Set<Course> getCourses() {
		return courses;
	}
	public void setCourses(Set<Course> courses) {
		this.courses = courses;
	}


}
