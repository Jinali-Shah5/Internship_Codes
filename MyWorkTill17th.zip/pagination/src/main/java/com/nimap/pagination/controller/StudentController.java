package com.nimap.pagination.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.nimap.pagination.entity.Student;
import com.nimap.pagination.repository.StudentRepository;
import com.nimap.pagination.service.StudentService;

@RestController
@RequestMapping("/students")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@GetMapping("/")
	public ResponseEntity<List<Student>> getAllStudents()
	
	{
		List<Student> list=studentService.findAll();

	return new ResponseEntity<List<Student>>(list,HttpStatus.OK);
		
		
	}
	@GetMapping("/{field}")
	public ResponseEntity<List<Student>> getAllStudentsBySorting(@PathVariable String field)
	
	{
		List<Student> list=studentService.findStudentBySorting(field);
	return new ResponseEntity<List<Student>>(list,HttpStatus.OK);	
	}
	@GetMapping("/pagination/{offset}/{pageSize}")
	public ResponseEntity<Page<Student>> getAllStudentsByPagination(@PathVariable int offset,@PathVariable int pageSize)
	{
		Page<Student> p=studentService.findStudentByPagination(offset, pageSize);
		return new ResponseEntity<Page<Student>>(p,HttpStatus.OK);
	}
}

