package com.nimap.pagination.repository;



import java.util.List;

import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Sort;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nimap.pagination.entity.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer>{

//	Page<Student> findAll(Pageable pageable);
//	List<Student> findAll(Sort sort);
}
