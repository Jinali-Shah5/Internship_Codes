package com.nima.retrievefromdb.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nima.retrievefromdb.entity.Customer;
import com.nima.retrievefromdb.repository.CustomerRepository;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerRepository repo;
	
	@GetMapping("/{id}")
	public ResponseEntity<Customer> getCustomerById( @PathVariable(value = "id") int id)
	{
		Customer customer=repo.findById(id);
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}
	
	@GetMapping("/")
	public ResponseEntity<List<Customer>> getCustomerByContactLastNameOrderByContactFirstName
	( @RequestBody String contactLastName )
	{
		List<Customer> customer=repo.findByContactLastNameOrderByContactFirstName(contactLastName);
		return new ResponseEntity<List<Customer>>(customer,HttpStatus.OK);
	}
	
}
