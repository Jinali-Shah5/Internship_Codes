
CREATE SCHEMA IF NOT EXISTS `customer` DEFAULT CHARACTER SET utf8 ;
USE `customer` ;

-- -----------------------------------------------------
-- Table `customer`.`customer`
-- -----------------------------------------------------
DROP TABLE customer;
CREATE TABLE IF NOT EXISTS `customer`.`customer` (
  `id` INT(45) NOT NULL,
  `contact_first_name` VARCHAR(45) NOT NULL,
  `contact_last_name` VARCHAR(45) NOT NULL,
  `phone_number` INT NOT NULL,
  `city` VARCHAR(45) NOT NULL,
  
  PRIMARY KEY (`id`))
ENGINE = InnoDB;

insert into customer values("Aakarsh","Mody",987004321,"Mumbai",1);
insert into customer values("Sayantan","Roy",996948166,"Mumbai",2);